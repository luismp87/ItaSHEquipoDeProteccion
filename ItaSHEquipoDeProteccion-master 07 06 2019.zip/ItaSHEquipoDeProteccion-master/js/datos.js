var usuarios = [
{"usuario": "varcos","pass": "varcos","origen": "ARCOS"},
{"usuario": "virapu","pass": "virapu","origen": "IRAPUATO"},
{"usuario": "varroc","pass": "varroc","origen": "ARROCERA"},
{"usuario": "vsalam","pass": "vsalam","origen": "SALAMANCA"},
{"usuario": "vsanta","pass": "vsanta","origen": "P_SANTA_ANITA"},
{"usuario": "vmoder","pass": "vmoder","origen": "MODERNA"},
{"usuario": "vbanex","pass": "vbanex","origen": "BANEXA"},
{"usuario": "vsblas","pass": "vsblas","origen": "SBLAS_30PNT"}
];
